% generates appended waveform file
function appendFourierWaveformsToOneFile

Vo = read_fem_fourier_waveform('ffw_reconstr_bipo2_encap250_136Hz_90us.txt');

pulseWidths = 10:10:500; % from, by, to % pulse width range in 0.01 ms unit (time_step)
nPulseWidths = length(pulseWidths);

fileName = 'simplePulseAllPulseWidths.txt'; % output file name
fileID = fopen(fileName,'w');
baseStr = 'fdw.x[';

i = 0;
for n = 1:nPulseWidths
    V = zeros(size(Vo)); % fills all 736 lines with 0
    V(1:pulseWidths(n)) = 1; % fills lines 0 to pulseWidth by 1
    
    for v = 1:length(V) % V is from the read function = 736
        A = [baseStr num2str(i) ']=' num2str(V(v)) char(13)]; % char(13) = \n % V() values are from the read function
        fwrite(fileID, A);
        i = i+1;
    end
end
fclose(fileID);
