function write_fem_fourier_waveform(fileName,V)

fileID = fopen(fileName,'w');
baseStr = 'fdw.x[';
for n = 1:length(V)
    A = [baseStr num2str(n-1) ']=' num2str(V(n)) char(13)];
    fwrite(fileID, A);
end
fclose(fileID)
