% Loads value from a voltage file

function [P,V] = read_fem_voltage(fileName)

fileID = fopen(fileName);
v=1;
p=1;
n=1;
while n~=0
    tline = fgets(fileID);
    if ischar(tline)
        if strfind(tline,'cell_pos.x')
            eqInd = strfind(tline,'=');
            P(p) = str2num(tline(eqInd+1:end));
            p=p+1;
        elseif strfind(tline,'V_raw.x')
            eqInd = strfind(tline,'=');
            V(v) = str2num(tline(eqInd+1:end));
            v=v+1;
        end
    else
        n=0;
    end
end
fclose(fileID);

P = reshape(P,3,length(P)/3);
nCells = length(P);
V = reshape(V,length(V)/nCells,nCells);



