% Loads value from an original waveform file

function V = read_fem_fourier_waveform(fileName)
% what this function does is storing all the values from the waveform file
% into V(n) values
% ! when you call the function, put full datapath (or use DataPath or use
% cd to change current folder
fileID = fopen(fileName);
n=1;
while n~=0 % ~= tests for difference. Will return True (1) if n is different than 0
    tline = fgets(fileID); % reads next line of the file
    if ischar(tline) % tests if the line is a character (returns true if it is)
        eqInd = strfind(tline,'='); % strfind finds one string in another. Will return position of the = on the line
        V(n) = str2num(tline(eqInd+1:end)); % eg. a = 'Hello'; eqInd = strfind (a, 'e') >> 2; a (eqInd + 1) >> 'l'
        % here, V(n) will be the voltage value (everything after the =)
        n=n+1;
    else
        n=0;
    end
end
fclose(fileID);