% Used to generate just/pre/postPulse waveform files
function allV = just_pre_postPulse

dataPath = 'C:\Users\u0043883\Google Drive\Work\Neuron Model\Model Miocinovic 2006\fem_fourier_waveform\';
Vo = read_fem_fourier_waveform([dataPath 'ffw_reconstr_bipo2_encap250_136Hz_90us.txt']);

fileName = ['postPulse'];

% set pulse width
Fac = 4; % ratio between per/post and pulse
pulseWidth = [2:2:130];
prePulseWidth = zeros(size(pulseWidth)); % pulseWidth*Fac; %
postPulseWidth = pulseWidth*Fac; % zeros(size(pulseWidth)); %

% set pulse amplitude
pulseAmp = 1;
prePulseAmp = -pulseAmp/Fac;
postPulseAmp = -pulseAmp/Fac;

nPulseWidths = length(pulseWidth);


fileID = fopen(fileName,'w');
baseStr = 'fdw.x[';

i = 0;
for n = 1:nPulseWidths
    V = zeros(size(Vo));
    
    V(1:prePulseWidth(n)) = prePulseAmp;
    V(prePulseWidth(n)+1:prePulseWidth(n)+pulseWidth(n)) = pulseAmp;
    V(prePulseWidth(n)+pulseWidth(n)+1:prePulseWidth(n)+pulseWidth(n)+postPulseWidth(n)) = postPulseAmp;
    
    for v = 1:length(V)
        A = [baseStr num2str(i) ']=' num2str(V(v)) char(13)];
        fwrite(fileID, A);
        i = i+1;
    end
    allV(:,n) = V;
end
fclose(fileID)
