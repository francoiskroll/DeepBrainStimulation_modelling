% Used to generate separate waveform files (one per pulse)

dataPath = '';
Vo = read_fem_fourier_waveform([dataPath 'ffw_reconstr_bipo2_encap250_136Hz_90us.txt']);

pulseWidths = [10:10:500];
nPulseWidths = length(pulseWidths);

for n = 1:nPulseWidths
    V = zeros(size(Vo));
    V(1:pulseWidths(n)) = 1;
    fileName = ['simplePulse' num2str(pulseWidths(n)) 'us.txt'];
    write_fem_fourier_waveform([dataPath fileName],V)
end