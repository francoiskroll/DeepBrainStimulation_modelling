/* Created by Language version: 6.2.0 */
/* NOT VECTORIZED */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "scoplib_ansi.h"
#undef PI
#define nil 0
#include "md1redef.h"
#include "section.h"
#include "nrniv_mf.h"
#include "md2redef.h"
 
#if METHOD3
extern int _method3;
#endif

#if !NRNGPU
#undef exp
#define exp hoc_Exp
extern double hoc_Exp(double);
#endif
 
#define _threadargscomma_ /**/
#define _threadargs_ /**/
 
#define _threadargsprotocomma_ /**/
#define _threadargsproto_ /**/
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 static double *_p; static Datum *_ppvar;
 
#define t nrn_threads->_t
#define dt nrn_threads->_dt
#define gcaT _p[0]
#define iCaT _p[1]
#define r _p[2]
#define s _p[3]
#define d _p[4]
#define eca _p[5]
#define cai _p[6]
#define cao _p[7]
#define Dr _p[8]
#define Ds _p[9]
#define Dd _p[10]
#define ica _p[11]
#define ralpha _p[12]
#define rbeta _p[13]
#define salpha _p[14]
#define sbeta _p[15]
#define dalpha _p[16]
#define dbeta _p[17]
#define _g _p[18]
#define _ion_cai	*_ppvar[0]._pval
#define _ion_cao	*_ppvar[1]._pval
#define _ion_eca	*_ppvar[2]._pval
#define _ion_ica	*_ppvar[3]._pval
#define _ion_dicadv	*_ppvar[4]._pval
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 
#if defined(__cplusplus)
extern "C" {
#endif
 static int hoc_nrnpointerindex =  -1;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static void _hoc_ghkg(void);
 static void _hoc_settables(void);
 static int _mechtype;
extern void _nrn_cacheloop_reg(int, int);
extern void hoc_register_prop_size(int, int, int);
extern void hoc_register_limits(int, HocParmLimits*);
extern void hoc_register_units(int, HocParmUnits*);
extern void nrn_promote(Prop*, int, int);
extern Memb_func* memb_func;
 extern void _nrn_setdata_reg(int, void(*)(Prop*));
 static void _setdata(Prop* _prop) {
 _p = _prop->param; _ppvar = _prop->dparam;
 }
 static void _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range(int);
 _prop = hoc_getdata_range(_mechtype);
   _setdata(_prop);
 hoc_retpushx(1.);
}
 /* connect user functions to hoc names */
 static VoidFunc hoc_intfunc[] = {
 "setdata_CaT", _hoc_setdata,
 "ghkg_CaT", _hoc_ghkg,
 "settables_CaT", _hoc_settables,
 0, 0
};
#define ghkg ghkg_CaT
 extern double ghkg( double , double , double , double );
 /* declare global and static user variables */
#define Q10 Q10_CaT
 double Q10 = 1.5158;
#define activate_Q10 activate_Q10_CaT
 double activate_Q10 = 1;
#define gmax_k gmax_k_CaT
 double gmax_k = 0;
#define gmaxQ10 gmaxQ10_CaT
 double gmaxQ10 = 1.5158;
#define rate_k rate_k_CaT
 double rate_k = 0;
#define tempb tempb_CaT
 double tempb = 23;
#define temp2 temp2_CaT
 double temp2 = 29;
#define temp1 temp1_CaT
 double temp1 = 19;
#define usetable usetable_CaT
 double usetable = 1;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 "usetable_CaT", 0, 1,
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "temp1_CaT", "degC",
 "temp2_CaT", "degC",
 "tempb_CaT", "degC",
 "gcaT_CaT", "mho/cm2",
 "iCaT_CaT", "mA/cm2",
 0,0
};
 static double delta_t = 1;
 static double d0 = 0;
 static double r0 = 0;
 static double s0 = 0;
 static double v = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "activate_Q10_CaT", &activate_Q10_CaT,
 "Q10_CaT", &Q10_CaT,
 "gmaxQ10_CaT", &gmaxQ10_CaT,
 "temp1_CaT", &temp1_CaT,
 "temp2_CaT", &temp2_CaT,
 "tempb_CaT", &tempb_CaT,
 "rate_k_CaT", &rate_k_CaT,
 "gmax_k_CaT", &gmax_k_CaT,
 "usetable_CaT", &usetable_CaT,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(Prop*);
static void  nrn_init(_NrnThread*, _Memb_list*, int);
static void nrn_state(_NrnThread*, _Memb_list*, int);
 static void nrn_cur(_NrnThread*, _Memb_list*, int);
static void  nrn_jacob(_NrnThread*, _Memb_list*, int);
 
static int _ode_count(int);
static void _ode_map(int, double**, double**, double*, Datum*, double*, int);
static void _ode_spec(_NrnThread*, _Memb_list*, int);
static void _ode_matsol(_NrnThread*, _Memb_list*, int);
 
#define _cvode_ieq _ppvar[5]._i
 /* connect range variables in _p that hoc is supposed to know about */
 static const char *_mechanism[] = {
 "6.2.0",
"CaT",
 "gcaT_CaT",
 "iCaT_CaT",
 0,
 0,
 "r_CaT",
 "s_CaT",
 "d_CaT",
 0,
 0};
 static Symbol* _ca_sym;
 
extern Prop* need_memb(Symbol*);

static void nrn_alloc(Prop* _prop) {
	Prop *prop_ion;
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 19, _prop);
 	/*initialize range parameters*/
 	gcaT = 0.001;
 	iCaT = 0;
 	_prop->param = _p;
 	_prop->param_size = 19;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 6, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 prop_ion = need_memb(_ca_sym);
 nrn_promote(prop_ion, 1, 1);
 	_ppvar[0]._pval = &prop_ion->param[1]; /* cai */
 	_ppvar[1]._pval = &prop_ion->param[2]; /* cao */
 	_ppvar[2]._pval = &prop_ion->param[0]; /* eca */
 	_ppvar[3]._pval = &prop_ion->param[3]; /* ica */
 	_ppvar[4]._pval = &prop_ion->param[4]; /* _ion_dicadv */
 
}
 static void _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 static void _update_ion_pointer(Datum*);
 extern Symbol* hoc_lookup(const char*);
extern void _nrn_thread_reg(int, int, void(*f)(Datum*));
extern void _nrn_thread_table_reg(int, void(*)(double*, Datum*, Datum*, _NrnThread*, int));
extern void hoc_register_tolerance(int, HocStateTolerance*, Symbol***);
extern void _cvode_abstol( Symbol**, double*, int);

 void _CaT_reg() {
	int _vectorized = 0;
  _initlists();
 	ion_reg("ca", -10000.);
 	_ca_sym = hoc_lookup("ca_ion");
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 0);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
     _nrn_setdata_reg(_mechtype, _setdata);
     _nrn_thread_reg(_mechtype, 2, _update_ion_pointer);
  hoc_register_prop_size(_mechtype, 19, 6);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 CaT C:/Users/Fran�ois/Dropbox/Documents/KUL/Neuron/Model McIntyre 2006/CaT.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double FARADAY = 96485.3;
 static double R = 8.31342;
 static double *_t_ralpha;
 static double *_t_rbeta;
 static double *_t_salpha;
 static double *_t_sbeta;
 static double *_t_dalpha;
 static double *_t_dbeta;
static int _reset;
static char *modelname = "calcium T channel for STh";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static void _modl_cleanup(){ _match_recurse=1;}
static int _f_settables(double);
static int settables(double);
 
static int _ode_spec1(_threadargsproto_);
/*static int _ode_matsol1(_threadargsproto_);*/
 static void _n_settables(double);
 static int _slist1[3], _dlist1[3];
 static int states(_threadargsproto_);
 
/*CVODE*/
 static int _ode_spec1 () {_reset=0;
 {
   settables ( _threadargscomma_ v ) ;
   Dr = ( ( ralpha * ( 1.0 - r ) ) - ( rbeta * r ) ) ;
   Dd = ( ( dbeta * ( 1.0 - s - d ) ) - ( dalpha * d ) ) ;
   Ds = ( ( salpha * ( 1.0 - s - d ) ) - ( sbeta * s ) ) ;
   }
 return _reset;
}
 static int _ode_matsol1 () {
 settables ( _threadargscomma_ v ) ;
 Dr = Dr  / (1. - dt*( ( ( (ralpha)*(( ( - 1.0 ) )) ) - ( (rbeta)*(1.0) ) ) )) ;
 Dd = Dd  / (1. - dt*( ( ( (dbeta)*(( ( - 1.0 ) )) ) - ( (dalpha)*(1.0) ) ) )) ;
 Ds = Ds  / (1. - dt*( ( ( (salpha)*(( ( - 1.0 ) )) ) - ( (sbeta)*(1.0) ) ) )) ;
 return 0;
}
 /*END CVODE*/
 static int states () {_reset=0;
 {
   settables ( _threadargscomma_ v ) ;
    r = r + (1. - exp(dt*(( ( (ralpha)*(( ( - 1.0 ) )) ) - ( (rbeta)*(1.0) ) ))))*(- ( ( ( (ralpha)*(( 1.0 )) ) ) ) / ( ( ( (ralpha)*(( ( - 1.0) )) ) - ( (rbeta)*(1.0) ) ) ) - r) ;
    d = d + (1. - exp(dt*(( ( (dbeta)*(( ( - 1.0 ) )) ) - ( (dalpha)*(1.0) ) ))))*(- ( ( ( (dbeta)*(( 1.0 - s )) ) ) ) / ( ( ( (dbeta)*(( ( - 1.0) )) ) - ( (dalpha)*(1.0) ) ) ) - d) ;
    s = s + (1. - exp(dt*(( ( (salpha)*(( ( - 1.0 ) )) ) - ( (sbeta)*(1.0) ) ))))*(- ( ( ( (salpha)*(( 1.0 - d )) ) ) ) / ( ( ( (salpha)*(( ( - 1.0) )) ) - ( (sbeta)*(1.0) ) ) ) - s) ;
   }
  return 0;
}
 static double _mfac_settables, _tmin_settables;
 static void _check_settables();
 static void _check_settables() {
  static int _maktable=1; int _i, _j, _ix = 0;
  double _xi, _tmax;
  static double _sav_celsius;
  if (!usetable) {return;}
  if (_sav_celsius != celsius) { _maktable = 1;}
  if (_maktable) { double _x, _dx; _maktable=0;
   _tmin_settables =  - 100.0 ;
   _tmax =  100.0 ;
   _dx = (_tmax - _tmin_settables)/400.; _mfac_settables = 1./_dx;
   for (_i=0, _x=_tmin_settables; _i < 401; _x += _dx, _i++) {
    _f_settables(_x);
    _t_ralpha[_i] = ralpha;
    _t_rbeta[_i] = rbeta;
    _t_salpha[_i] = salpha;
    _t_sbeta[_i] = sbeta;
    _t_dalpha[_i] = dalpha;
    _t_dbeta[_i] = dbeta;
   }
   _sav_celsius = celsius;
  }
 }

 static int settables(double _lv){ _check_settables();
 _n_settables(_lv);
 return 0;
 }

 static void _n_settables(double _lv){ int _i, _j;
 double _xi, _theta;
 if (!usetable) {
 _f_settables(_lv); return; 
}
 _xi = _mfac_settables * (_lv - _tmin_settables);
 if (isnan(_xi)) {
  ralpha = _xi;
  rbeta = _xi;
  salpha = _xi;
  sbeta = _xi;
  dalpha = _xi;
  dbeta = _xi;
  return;
 }
 if (_xi <= 0.) {
 ralpha = _t_ralpha[0];
 rbeta = _t_rbeta[0];
 salpha = _t_salpha[0];
 sbeta = _t_sbeta[0];
 dalpha = _t_dalpha[0];
 dbeta = _t_dbeta[0];
 return; }
 if (_xi >= 400.) {
 ralpha = _t_ralpha[400];
 rbeta = _t_rbeta[400];
 salpha = _t_salpha[400];
 sbeta = _t_sbeta[400];
 dalpha = _t_dalpha[400];
 dbeta = _t_dbeta[400];
 return; }
 _i = (int) _xi;
 _theta = _xi - (double)_i;
 ralpha = _t_ralpha[_i] + _theta*(_t_ralpha[_i+1] - _t_ralpha[_i]);
 rbeta = _t_rbeta[_i] + _theta*(_t_rbeta[_i+1] - _t_rbeta[_i]);
 salpha = _t_salpha[_i] + _theta*(_t_salpha[_i+1] - _t_salpha[_i]);
 sbeta = _t_sbeta[_i] + _theta*(_t_sbeta[_i+1] - _t_sbeta[_i]);
 dalpha = _t_dalpha[_i] + _theta*(_t_dalpha[_i+1] - _t_dalpha[_i]);
 dbeta = _t_dbeta[_i] + _theta*(_t_dbeta[_i+1] - _t_dbeta[_i]);
 }

 
static int  _f_settables (  double _lv ) {
   double _lbd ;
 ralpha = rate_k * 1.0 / ( 1.7 + exp ( - ( _lv + 26.2722 ) / 13.5 ) ) ;
   rbeta = rate_k * exp ( - ( _lv + 61.0722 ) / 7.8 ) / ( exp ( - ( _lv + 26.8722 ) / 13.1 ) + 1.7 ) ;
   salpha = rate_k * exp ( - ( _lv + 158.3722 ) / 17.8 ) ;
   sbeta = rate_k * ( sqrt ( 0.25 + exp ( ( _lv + 81.5722 ) / 6.3 ) ) - 0.5 ) * ( exp ( - ( _lv + 158.3722 ) / 17.8 ) ) ;
   _lbd = sqrt ( 0.25 + exp ( ( _lv + 81.5722 ) / 6.3 ) ) ;
   dalpha = rate_k * ( 1.0 + exp ( ( _lv + 35.4722 ) / 30.0 ) ) / ( 240.0 * ( 0.5 + _lbd ) ) ;
   dbeta = rate_k * ( _lbd - 0.5 ) * dalpha ;
    return 0; }
 
static void _hoc_settables(void) {
  double _r;
    _r = 1.;
 settables (  *getarg(1) );
 hoc_retpushx(_r);
}
 
double ghkg (  double _lv , double _lci , double _lco , double _lz ) {
   double _lghkg;
 double _lnu , _lf , _lenu , _lfnu ;
 _lf = ( 1.0e3 / _lz ) * R * ( celsius + 273.15 ) / FARADAY ;
   _lnu = _lv / _lf ;
   _lenu = exp ( _lnu ) ;
   if ( fabs ( _lnu ) < 1e-4 ) {
     _lfnu = 1.0 - _lnu / 2.0 ;
     }
   else {
     _lfnu = _lnu / ( _lenu - 1.0 ) ;
     }
   _lghkg = - _lf * ( 1.0 - ( _lci / _lco ) * _lenu ) * _lfnu ;
   
return _lghkg;
 }
 
static void _hoc_ghkg(void) {
  double _r;
   _r =  ghkg (  *getarg(1) , *getarg(2) , *getarg(3) , *getarg(4) );
 hoc_retpushx(_r);
}
 
static int _ode_count(int _type){ return 3;}
 
static void _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
  eca = _ion_eca;
     _ode_spec1 ();
  }}
 
static void _ode_map(int _ieq, double** _pv, double** _pvdot, double* _pp, Datum* _ppd, double* _atol, int _type) { 
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 3; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static void _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
  cai = _ion_cai;
  cao = _ion_cao;
  eca = _ion_eca;
 _ode_matsol1 ();
 }}
 extern void nrn_update_ion_pointer(Symbol*, Datum*, int, int);
 static void _update_ion_pointer(Datum* _ppvar) {
   nrn_update_ion_pointer(_ca_sym, _ppvar, 0, 1);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 1, 2);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 2, 0);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 3, 3);
   nrn_update_ion_pointer(_ca_sym, _ppvar, 4, 4);
 }

static void initmodel() {
  int _i; double _save;_ninits++;
 _save = t;
 t = 0.0;
{
  d = d0;
  r = r0;
  s = s0;
 {
   double _lktemp , _lktempb , _lktemp1 , _lktemp2 ;
 if ( activate_Q10 > 0.0 ) {
     _lktemp = celsius + 273.0 ;
     _lktempb = tempb + 273.0 ;
     _lktemp1 = temp1 + 273.0 ;
     _lktemp2 = temp2 + 273.0 ;
     rate_k = exp ( log ( Q10 ) * ( ( 1.0 / _lktempb ) - ( 1.0 / _lktemp ) ) / ( ( 1.0 / _lktemp1 ) - ( 1.0 / _lktemp2 ) ) ) ;
     gmax_k = exp ( log ( gmaxQ10 ) * ( ( 1.0 / _lktempb ) - ( 1.0 / _lktemp ) ) / ( ( 1.0 / _lktemp1 ) - ( 1.0 / _lktemp2 ) ) ) ;
     }
   else {
     rate_k = 1.0 ;
     gmax_k = 1.0 ;
     }
   settables ( _threadargscomma_ v ) ;
   r = ralpha / ( ralpha + rbeta ) ;
   s = ( salpha * ( dbeta + dalpha ) - ( salpha * dbeta ) ) / ( ( salpha + sbeta ) * ( dalpha + dbeta ) - ( salpha * dbeta ) ) ;
   d = ( dbeta * ( salpha + sbeta ) - ( salpha * dbeta ) ) / ( ( salpha + sbeta ) * ( dalpha + dbeta ) - ( salpha * dbeta ) ) ;
   }
  _sav_indep = t; t = _save;

}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
  cai = _ion_cai;
  cao = _ion_cao;
  eca = _ion_eca;
 initmodel();
 }}

static double _nrn_current(double _v){double _current=0.;v=_v;{ {
   ica = ( gcaT * gmax_k ) * r * r * r * s * ghkg ( _threadargscomma_ v , cai , cao , 2.0 ) ;
   iCaT = ica ;
   }
 _current += ica;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
  cai = _ion_cai;
  cao = _ion_cao;
  eca = _ion_eca;
 _g = _nrn_current(_v + .001);
 	{ double _dica;
  _dica = ica;
 _rhs = _nrn_current(_v);
  _ion_dicadv += (_dica - ica)/.001 ;
 	}
 _g = (_g - _rhs)/.001;
  _ion_ica += ica ;
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type){
 double _break, _save;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
  cai = _ion_cai;
  cao = _ion_cao;
  eca = _ion_eca;
 { {
 for (; t < _break; t += dt) {
 error =  states();
 if(error){fprintf(stderr,"at line 70 in file CaT.mod:\n	SOLVE states METHOD cnexp\n"); nrn_complain(_p); abort_run(error);}
 
}}
 t = _save;
 } }}

}

static void terminal(){}

static void _initlists() {
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(r) - _p;  _dlist1[0] = &(Dr) - _p;
 _slist1[1] = &(d) - _p;  _dlist1[1] = &(Dd) - _p;
 _slist1[2] = &(s) - _p;  _dlist1[2] = &(Ds) - _p;
   _t_ralpha = makevector(401*sizeof(double));
   _t_rbeta = makevector(401*sizeof(double));
   _t_salpha = makevector(401*sizeof(double));
   _t_sbeta = makevector(401*sizeof(double));
   _t_dalpha = makevector(401*sizeof(double));
   _t_dbeta = makevector(401*sizeof(double));
_first = 0;
}
