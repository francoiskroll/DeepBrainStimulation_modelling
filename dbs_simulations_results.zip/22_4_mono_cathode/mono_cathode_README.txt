Run on old laptop (Packard Bell).
Started 21/4/2017 18.07
Finished 22/4/2017 23.00 (guess)