Run on Asus laptop.
Started 20/4/2017 12.00
Finished 20/4/2017 00.00