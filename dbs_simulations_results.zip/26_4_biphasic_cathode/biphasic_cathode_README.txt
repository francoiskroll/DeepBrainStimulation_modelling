Run on old laptop (Packard Bell).
Started 25/4/2017 12.30
Finished 26/4/2017 00.32