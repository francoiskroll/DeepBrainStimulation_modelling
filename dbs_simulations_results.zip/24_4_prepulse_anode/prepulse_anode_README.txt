Run on Asus laptop.
Started 24/4/2017 00.39
Finished 24/4/2017 10.00 (guess)