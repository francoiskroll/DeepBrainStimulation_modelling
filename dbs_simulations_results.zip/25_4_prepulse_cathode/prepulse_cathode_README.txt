Run on Asus laptop.
Started 25/4/2017 00.10
Finished 25/4/2017 12.25