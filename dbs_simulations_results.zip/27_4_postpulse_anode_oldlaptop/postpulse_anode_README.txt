Run on old laptop (Packard Bell).
Started 25/4/2017 00.34
Finished 27/4/2017 10.00