Run on Asus laptop.
Started 18/4/2017 23.00
Finished 20/4/2017 11.41
