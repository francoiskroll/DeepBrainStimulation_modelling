Run on Asus laptop.
Started 26/4/2017 00.35
Finished 26/4/2017 13.20