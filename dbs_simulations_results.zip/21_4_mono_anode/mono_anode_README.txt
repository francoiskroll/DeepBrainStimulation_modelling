Run on old laptop (Packard Bell).
Started 20/4/2017 12.10
Finished 21/4/2017 17.45