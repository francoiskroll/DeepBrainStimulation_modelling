Run on Asus laptop.
Started 26/4/2017 13.23
Finished 27/4/2017 10.00