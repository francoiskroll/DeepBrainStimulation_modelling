# PLOT ONE STIMULATION AP AND ONE SPONTANEOUS AP
# Works with functions!
# There is way too much

library (reshape2)
library (dplyr)
library (ggplot2)
library(extrafont)
# loadfonts(device = "win")

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/rawTimeFiles")
name = "clinical_cathode"
name_timefile = paste (name, '.time', sep = '')
name_logfile = paste (name, '.log', sep = '')
num_sections <- 29

num_col <- max(count.fields(name_timefile, sep = "\t"))
times <- read.table(name_timefile, sep="\t", fill=TRUE, col.names=1:(num_col-1))
num_pulses <- nrow (times) / num_sections
Raw <- split (times, rep (0:(nrow(times)/29), each = 29, length.out = nrow(times)))
APTimes <- Raw
APTimes <- APTimes [- 1]
APTimes <- lapply (APTimes, FUN = extendMatrix)
APTimes <- lapply (APTimes, FUN = lastLineFirst)
APTimes <- lapply (APTimes, FUN = deleteFirstCol) 
APTimes <- lapply (APTimes, FUN = correctTimeFile)
APTimes <- lapply (APTimes, FUN = deleteColsLastRowNA)

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/logFiles")
pulses <- read.table(name_logfile, sep="\t", fill=TRUE, col.names=1:(max(count.fields(name_timefile, sep = "\t"))-1))
pulses <- tail (head (pulses, n = 58), n = 25)
pulses <- pulses [,-seq(3, ncol(pulses))]
rownames (pulses) <- NULL
colnames(pulses) <- c('num', 'time')

pulse_times <- as.numeric(as.vector(pulses$time))

AllIndexes <- lapply (APTimes, function (x) {seq(1:ncol(x))})
all_inds <- listListsToMatrix(AllIndexes)
StimulationIndexes <- lapply (APTimes, FUN = getStimulationAPsIndexes, pulse_times = pulse_times)
stimulation_inds <- listListsToMatrix(StimulationIndexes)
SpontaneousIndexes <- list()

for (i in seq(1:length(AllIndexes))) {
  initially <- AllIndexes [[i]]
  indexes <- StimulationIndexes [[i]]  
  spontaneous <- initially [!(initially %in%  indexes)]
  SpontaneousIndexes [[length(SpontaneousIndexes) + 1]] <- spontaneous
}

spontaneous_inds <- listListsToMatrix(SpontaneousIndexes)

StimulationAPs <- list()
SpontaneousAPs <- list()

for (c in seq(1:length(StimulationIndexes))) {
  tab <- as.matrix (APTimes[[c]] [, StimulationIndexes[[c]] ])
  StimulationAPs [[length(StimulationAPs) + 1]] <- tab
}

for (c in seq(1:length(SpontaneousIndexes))) {
  tab <- as.matrix (APTimes[[c]] [, SpontaneousIndexes[[c]] ])
  SpontaneousAPs [[length(SpontaneousAPs) + 1]] <- tab
}

colmins_stim <- lapply (StimulationAPs, FUN = colMinsIndexes)
colmins_spon <- lapply (SpontaneousAPs, FUN = colMinsIndexes)

ini_sites_stim <- lapply (colmins_stim, FUN = meansOfSublists)
ini_sites_spon <- lapply (colmins_spon, FUN = meansOfSublists)

ini_mat_stim <- listListsToMatrix(ini_sites_stim)
ini_mat_spon<- listListsToMatrix(ini_sites_spon)

ini_mat_stim <- nullToNA (ini_mat_stim)
ini_mat_spon <- nullToNA (ini_mat_spon)

donotuse <- c(1, 2) # !! ONLY WHEN ANODE !!
ini_mat_stim[, donotuse] <- NA
ini_mat_spon[, donotuse] <- NA

odds <- seq (from = 1, to = 65, by = 2) # Removes every other pulse for clarity.
ini_mat_spon [, odds] <- NA
ini_mat_stim [, odds] <- NA

ini_mat_stim <- apply (ini_mat_stim, 2, as.numeric)
ini_mat_spon <- apply (ini_mat_spon, 2, as.numeric)

colnames (ini_mat_stim) <- NULL
colnames (ini_mat_spon) <- NULL

ini_melted_stim <- melt (ini_mat_stim, na.rm = TRUE)
ini_melted_spon <- melt (ini_mat_spon, na.rm = TRUE)

colnames(ini_melted_stim) <- c("APnum", "pulse", "ini_site")
colnames(ini_melted_spon) <- c("APnum", "pulse", "ini_site")

ini_grouped_stim <- group_by (ini_melted_stim, pulse, ini_site)
ini_grouped_spon <- group_by (ini_melted_spon, pulse, ini_site)

ini_counts_stim <- count (ini_grouped_stim)
ini_counts_spon <- count (ini_grouped_spon)

colnames(ini_counts_stim) <- c("pulse", "ini_site", "numAPs")
colnames(ini_counts_spon) <- c("pulse", "ini_site", "numAPs")

# I want APs when pw = 0.2 ms.
# ie. the 11th pulse

pulse11 <- APTimes [[11]]

# I can get which one is spontaneous or stimulation with SpontaneousIndexes
SpontaneousIndexes [[11]] # 10, 18, 27
StimulationIndexes [[11]] # Every other

cols <- c('#FF4040', '#025D8C')

# I'll plot the 10th and the 11th AP.
matplot (x = pulse11[,c(10, 11)], y = seq(from = 1, to = 29), 
         col = cols, type = 'l', bty = 'l', lty = 1, lwd = 2, 
         ylab = NA, ylim = c(0, 28.1), 
         xlab = NA, xlim = c(155, 169),
         axes = T, family = 'Calibri Light', 
         xaxs = 'i',
         yaxt = 'n') +
  
  matpoints (x = pulse11[,c(10, 11)], y = seq(from = 1, to = 29), 
             pch = 21, cex = 0.85, col = cols)
par (bg = NA)
axis (2, at = c(seq(1,29,2)), labels = c('0', '', '4', '', '8', '', '12', '', '16', '', '20', '', '24', '', '28'))
