# Postpulse anode 4 ms vs Postpulse anode 7.35 ms

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/ALLRAWFILES")
library(extrafont)
# loadfonts(device = "win")
library(RColorBrewer)

# Replace in a tab the thresholds which are = 10 by NA
emptyThresh10 <- function (col) {
  if (length(which (col == 10)) != 0) {
    ind <- which (col == 10)
    col [ind] <- NA
    return (col)
  }
}

# What are the pulse widths you tested (in ms)?
first = 0.02
last = 1.3
increment = 0.02

# There are 33 columns to the .dat file
dat_colnames = c('Pulse #', 'Cell #', 'X', 'Y', 'Z', 'Thresh voltage(V)', 'ubound', 'lbound', 'Required APs', 
                 'Nbr extra APs during stim', 'Avg spikes/sec B(Hz)', 'Avg Inst firing B (Hz)',
                 'Inst rate STD B (Hz)', 'Avg spikes/sec SOMA B(Hz)',
                 'Avg Inst firing SOMA B (Hz)', 'Avg spikes/sec D (Hz)',
                 'Avg Inst firing D', 'Inst rate STD D (Hz)', 'Avg spikes/sec SOMA D(Hz)',
                 'Avg Inst firing SOMA D (Hz)', 'Avg spikes/sec A (Hz)', 'Avg Inst firing A',
                 'Inst rate STD A (Hz)', 'Avg spikes/sec SOMA A(Hz)', 'Avg Inst firing SOMA A (Hz)',
                 'Avg freq D aft 100ms(Hz)', 'Delay after stim (ms)', 'AP site#1', 'AP site#2',
                 'AP time1', 'AP time2', 'soma_orig', 'soma_orig2', 'Nbr soma AP during stim')

# Import the .dat tables

postpulse_anode_735 <- read.table ('postpulse_anode_735ms.dat', header = FALSE, sep = '', col.names = dat_colnames,  skip = 12)
postpulse_anode_4 <- read.table ('postpulse_anode.dat', header = FALSE, sep = '', col.names = dat_colnames,  skip = 12)

# Extract the thresholds from the .dat tables

prepulse_anode_735_thr <- postpulse_anode_735 [,6]
prepulse_anode_4_thr <- postpulse_anode_4 [,6]

thresholds <- cbind (prepulse_anode_4_thr, prepulse_anode_735_thr)

thresholds <- thresholds [-1,]
thresholds <- emptyThresh10(thresholds)

pulse_widths <- seq(from = first, to = last, by = increment)

matplot (thresholds)