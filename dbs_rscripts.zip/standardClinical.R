# PLOT THE STANDARD CLINICAL PULSE
# Data is from folder New Pulse Shape Files

#################################

# COMMON TO ALL
# Including some functions

library(extrafont)
loadfonts(device = "win")

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/New Pulse Shape Files")

real_time <- seq (from = 0.00, to = 7.36, by = 0.01)

plot_grey <- grey.colors (3, start = 0.2, end = 0.9)
plot_heat <- heat.colors (3)

listListsToMatrix <- function (list_lists) {
  # also works when list of integers
  max_length <- max(unlist(lapply (list_lists, FUN = length)))
  matrix_lists <- sapply (list_lists, function (x) {length (x) <- max_length; return (x)})
  rownames(matrix_lists) <- seq (1:nrow(matrix_lists))
  return (matrix_lists)
}

# Takes a big appended file of pulses waveforms as input
# and return the corresponding matrix where each column is one pulse.
fromWaveformsToMatrix <- function (waveform) {
  waveform <- waveform [,-1] # deletes the first column (times)
  splitted <- split (waveform, ceiling(seq_along(waveform)/736))
  waveform_mat <- listListsToMatrix(splitted)
  return (waveform_mat)
}

#################################

# CLINICAL CATHODE

clinical_cathode_raw <- read.table ('clinical_cathode.txt',
                                    sep = '=', col.names = c('time', 'volt'))

clinical_cathode <- fromWaveformsToMatrix(clinical_cathode_raw)

std_pulse <- as.matrix (clinical_cathode [,11])
std_pulse <- rbind (0, std_pulse)
par (bg = NA)
# 0.2 ms pulse is the 11th pulse
plot (real_time, std_pulse, family = 'Calibri Light',
         lty = 1, lwd = 2, col = '#FF0202', type = 'l',
         xlab = '', ylab = '', xaxt = 'n', yaxt = 'n', bty = 'l', bg = NA)

axis(side = 1, at = c(0, 2, 4, 6), labels = c('0', '2', '4', '6'), family = 'Calibri Light', lwd.ticks = 1)

axis(side = 2, at = c(-1, 0, 0.1), labels = c('-1', '0', '0.1'), family = 'Calibri Light', lwd.ticks = 1)

axis(side = 1, at = c(0.2), labels = '',
     las = 1, family = 'Calibri Light', lwd.ticks = 1)

abline (h = 0, lty = 'dotted', col = '#3f3f3f', lwd = 2.0)