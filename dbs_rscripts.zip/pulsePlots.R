# PLOT THE WAVEFORMS
  # Data is from folder New Pulse Shape Files

#################################

# COMMON TO ALL
  # Including some functions

library(extrafont)
loadfonts(device = "win")

library(RColorBrewer)

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/New Pulse Shape Files")

real_time <- seq (from = 0.01, to = 7.36, by = 0.01)

plot_grey <- grey.colors (3, start = 0.2, end = 0.9)
plot_heat <- heat.colors (3)
plot_ord <- brewer.pal (3, "OrRd")
plot_reds <- brewer.pal (3, "Reds")
plot_reds <- tail (plot_reds, 2)

cols <- c('#343335', '#B1AEB2',
          '#043264', '#4476E4',
          '#506620', '#98C23C',
          '#871F07', '#F33F15',
          '#7B109C', '#CC5BEF')

#################################
# Best way to visualize is probably to plot first and last pulse.

# BIPHASIC_ANODE

biphasic_anode_raw <- read.table ('biphasic_anode.txt',
                         sep = '=', col.names = c('time', 'volt'))

biphasic_anode <- fromWaveformsToMatrix(biphasic_anode_raw)

matplot (real_time, biphasic_anode [,c(66)],
         col = cols[10],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# BIPHASIC_CATHODE

biphasic_cathode_raw <- read.table ('biphasic_cathode.txt',
                                    sep = '=', col.names = c('time', 'volt'))

biphasic_cathode <- fromWaveformsToMatrix(biphasic_cathode_raw)


matplot (real_time, biphasic_cathode [,c(66)],
         col = cols[9],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# clinical_anode

clinical_anode_raw <- read.table ('clinical_anode.txt',
                                    sep = '=', col.names = c('time', 'volt'))

clinical_anode <- fromWaveformsToMatrix(clinical_anode_raw)


matplot (real_time, clinical_anode [,c(66)],
         col = cols[4],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# clinical_cathode

clinical_cathode_raw <- read.table ('clinical_cathode.txt',
                                  sep = '=', col.names = c('time', 'volt'))

clinical_cathode <- fromWaveformsToMatrix(clinical_cathode_raw)


matplot (real_time, clinical_cathode [,c(66)],
         col = cols[3],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# mono_anode

mono_anode_raw <- read.table ('mono_anode.txt',
                                    sep = '=', col.names = c('time', 'volt'))

mono_anode <- fromWaveformsToMatrix(mono_anode_raw)


matplot (real_time, mono_anode [,c(66)],
         col = cols[2],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)
#################################

# mono_cathode

mono_cathode_raw <- read.table ('mono_cathode.txt',
                              sep = '=', col.names = c('time', 'volt'))

mono_cathode <- fromWaveformsToMatrix(mono_cathode_raw)


matplot (real_time, mono_cathode [,c(66)],
         col = cols[1],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# postpulse_anode

postpulse_anode_raw <- read.table ('postpulse_anode.txt',
                                sep = '=', col.names = c('time', 'volt'))

postpulse_anode <- fromWaveformsToMatrix(postpulse_anode_raw)


matplot (real_time, postpulse_anode [,c(66)],
         col = cols[6],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# postpulse_cathode

postpulse_cathode_raw <- read.table ('postpulse_cathode.txt',
                                   sep = '=', col.names = c('time', 'volt'))

postpulse_cathode <- fromWaveformsToMatrix(postpulse_cathode_raw)


matplot (real_time, postpulse_cathode [,c(66)],
         col = cols[5],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# prepulse_anode

prepulse_anode_raw <- read.table ('prepulse_anode.txt',
                                     sep = '=', col.names = c('time', 'volt'))

prepulse_anode <- fromWaveformsToMatrix(prepulse_anode_raw)


matplot (real_time, prepulse_anode [,c(66)],
         col = cols[8],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)

#################################

# prepulse_cathode

prepulse_cathode_raw <- read.table ('prepulse_cathode.txt',
                                  sep = '=', col.names = c('time', 'volt'))

prepulse_cathode <- fromWaveformsToMatrix(prepulse_cathode_raw)


matplot (real_time, prepulse_cathode [,c(66)],
         col = cols[7],
         lty = 1, lwd = 2, type = 'l', 
         xlab = '', xlim = c(0, 7),
         ylab = '', ylim = c(-1, 1),
         xaxt = 'n', yaxt = 'n')
axis (1, at = c(0, 1, 2, 3, 4, 5, 6, 7), labels = c('0', '1', '2', '3', '4', '5', '6', '7'), family = 'Calibri Light')
axis (2, at = c(-1, -0.5, 0, 0.5, 1), labels = c('-1', '','0', '', '1'), family = 'Calibri Light')
abline (h = 0.0, lty = 2, lwd = 1, col = '#2a2a2a')
par (bg = NA)