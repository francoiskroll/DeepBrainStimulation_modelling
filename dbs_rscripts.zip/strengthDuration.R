# STRENGTH-DURATION GRAPH
  # also contains the calculation of the RHEOBASE and CHRONAXIE

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/19_5_prepulse_cathode_5msdelay")
library(extrafont)
loadfonts(device = "win")

name = 'prepulse_cathode.dat'

# What are the pulse widths you tested (in ms)?
first = 0.02
last = 1.3
increment = 0.02

# There are 33 columns to the .dat file
dat_colnames = c('Pulse #', 'Cell #', 'X', 'Y', 'Z', 'Thresh voltage(V)', 'ubound', 'lbound', 'Required APs', 
                 'Nbr extra APs during stim', 'Avg spikes/sec B(Hz)', 'Avg Inst firing B (Hz)',
                 'Inst rate STD B (Hz)', 'Avg spikes/sec SOMA B(Hz)',
                 'Avg Inst firing SOMA B (Hz)', 'Avg spikes/sec D (Hz)',
                 'Avg Inst firing D', 'Inst rate STD D (Hz)', 'Avg spikes/sec SOMA D(Hz)',
                 'Avg Inst firing SOMA D (Hz)', 'Avg spikes/sec A (Hz)', 'Avg Inst firing A',
                 'Inst rate STD A (Hz)', 'Avg spikes/sec SOMA A(Hz)', 'Avg Inst firing SOMA A (Hz)',
                 'Avg freq D aft 100ms(Hz)', 'Delay after stim (ms)', 'AP site#1', 'AP site#2',
                 'AP time1', 'AP time2', 'soma_orig', 'soma_orig2', 'Nbr soma AP during stim')

# Import the .dat table
simul_dat <- read.table (name, header = FALSE, sep = '', col.names = dat_colnames,  skip = 12)

# Extract the thresholds from .dat
thresh <- simul_dat [,6]

# Add a column for pulse widths and organize the data in a matrix for easier use
pulse_widths <- seq(from = first - increment, to = last, by = increment) 
# Pulse of width (first - increment) is NOT tested. It is just to add one to pulse_widths so we can cbind.
# First pulse width tested is actually repeated because of the first pulse bug. We will delete it anyway.
thresh <- cbind (thresh, pulse_widths)
thresh <- thresh [,c(2,1)] # Changes the order of the columns
colnames (thresh) <- c('pw', 'volt')

# Delete the first value 
  # (first pulse tested is always a bug, that is why first pulse width is repeated twice)
thresh <- thresh [-1,]

# Delete when threshold = 10 V.
# This is what the model returns when it cannot activate the neuron; it isn't actual data.
if (which (thresh [,2] == 10) != 0) {
  thresh <- thresh[- which (thresh[,2] == 10),]
}
# Compute the rheobase
  # assumes than last threshold = maximum pulse duration.
  # first checks than the last 3 thresholds are equal to be safe

are_last_three_equal = 
  thresh[nrow(thresh), 2] == thresh[nrow(thresh)-2, 2] &&
  thresh[nrow(thresh) - 1, 2] == thresh[nrow(thresh)-2, 2]

if (are_last_three_equal == TRUE) {
  print ("--> Three last thresholds are equal. <-- ")
  
} else {
  print ("--> THREE LAST TRESHOLDS ARE NOT EQUAL. <-- ")
  print ("Manually check what you are doing.")
}

rheobase = thresh[nrow(thresh), 2]

# Compute the chronaxie
chron_lookfor <- rheobase * 2

chronaxie <- mean(thresh[which (abs(thresh[,2] - chron_lookfor) == min (abs(thresh[,2] - chron_lookfor))), 1])
# They may be a couple thresholds whose voltage are closest to chron_volt
  # We take the average of their pulse durations

# Plot the strength duration graph
plot (thresh, bty = 'l', type = 'l', lwd = 3, col = '#9E0000', family = 'Calibri Light',
      xlim = c(0, pulse_widths[length(pulse_widths)] + 0.1), ylim = c(0, 8.5),
      xlab = '', ylab = '',
      xaxs = 'i', yaxs = 'i', xaxt = 'n', yaxt = 'n')
# xaxs = 'i', yaxs = 'i' put axes origins at 0.
par (bg = NA)
points (thresh, pch = 21, cex = 0.85, col = '#2a2a2a')
# points (thresh, pch = 20, cex = 1.0, col = '#151515') # full points

abline (v = chronaxie, lty = 'dotted', col = '#3f3f3f', lwd = 2.0)
axis(side = 1, at = c(chronaxie - 0.004), labels = 'chronaxie',
     las = 2, family = 'Calibri Light', lwd.ticks = 0)
axis (side = 1, 
      at = c(0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4), 
      labels = c('0.0', '', '0.4', '0.6', '0.8', '1.0', '1.2', '1.4'),
      family = 'Calibri Light')

abline (h = rheobase, lty = 'dotted', col = '#3f3f3f', lwd = 2.0)
axis(side = 2, at = c(rheobase + 0.05), labels = 'rheobase', 
     las = 2, family = 'Calibri Light', lwd.ticks = 0, lwd = 0)
axis (side = 2, at = c(0, 2, 4, 6, 8), labels = c('0', '2', '4', '6', '8'), family = 'Calibri Light')
# axis (side = 2, at = c(0, 2, 4, 6, 8), labels = c('', '', '', '', ''))

# title ('Clinical anode', font.main = 1, family = 'Calibri Light', cex.main = 1.8, line = 2.8)
# mtext ('Strength-duration curve', family = 'Calibri Light', line = 1.3) # adds a subtitle

# Export

# dev.copy (png,'SDC.png', family = "Calibri Light")
# dev.off()

# You might not need family = 'Calibri' (it is already in the plot command).