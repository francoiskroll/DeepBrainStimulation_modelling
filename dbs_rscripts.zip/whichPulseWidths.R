# WHICH PULSE WIDTHS?
  # What are the pulse widths of the pulses in New Pulse Shape Files folder

#################################

# COMMON TO ALL
  # Including some functions

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/New Pulse Shape Files")

real_time <- seq (from = 0.01, to = 7.36, by = 0.01)

plot_grey <- grey.colors (3, start = 0.2, end = 0.9)
plot_heat <- heat.colors (3)

listListsToMatrix <- function (list_lists) {
  # also works when list of integers
  max_length <- max(unlist(lapply (list_lists, FUN = length)))
  matrix_lists <- sapply (list_lists, function (x) {length (x) <- max_length; return (x)})
  rownames(matrix_lists) <- seq (1:nrow(matrix_lists))
  return (matrix_lists)
}

# Takes a big appended file of pulses waveforms as input
# and return the corresponding matrix where each column is one pulse.
fromWaveformsToMatrix <- function (waveform) {
  waveform <- waveform [,-1] # deletes the first column (times)
  splitted <- split (waveform, ceiling(seq_along(waveform)/736))
  waveform_mat <- listListsToMatrix(splitted)
  return (waveform_mat)
}

#################################

# EG. WITH CLINICAL ANODE

clinical_anode_raw <- read.table ('clinical_anode.txt',
                                  sep = '=', col.names = c('time', 'volt'))

clinical_anode <- fromWaveformsToMatrix(clinical_anode_raw)

# Increment is two time steps
  # = 2 * 0.01 ms = 0.02 ms.

# Pulse 1 is 1 until line 2 ie. pulse of 0.02 ms.
# Pulse 66 is 1 until line 130 ie. pulse of 130 * 0.01 ms = 1.3 ms.

# One column = one pulse = 736 rows = 7.36 ms.

pulse_widths <- seq (from = 0.02, to = 1.3, by = 0.02)
# That's 65 different widths.
# + first one is repeated because of the bug = 66 pulses.