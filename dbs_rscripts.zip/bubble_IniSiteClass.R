# BUBBLES WITH CLASSIFICATION BASED ON INI SITE SOMA VS AXON
# Not the 4 ms condition which can be messy.

library (reshape2)
library (dplyr)
library (ggplot2)
library(extrafont)
# loadfonts(device = "win")

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/ALLRAWFILES")
name = "clinical_anode"
isanode = TRUE

name_timefile = paste (name, '.time', sep = '')
name_logfile = paste (name, '.log', sep = '')
num_sections <- 29

num_col <- max(count.fields(name_timefile, sep = "\t"))
times <- read.table(name_timefile, sep="\t", fill=TRUE, col.names=1:(num_col-1))
num_pulses <- nrow (times) / num_sections
Raw <- split (times, rep (0:(nrow(times)/29), each = 29, length.out = nrow(times)))
APTimes <- Raw
APTimes <- APTimes [- 1]
APTimes <- lapply (APTimes, FUN = extendMatrix)
APTimes <- lapply (APTimes, FUN = lastLineFirst)
APTimes <- lapply (APTimes, FUN = deleteFirstCol) 
APTimes <- lapply (APTimes, FUN = correctTimeFile)
APTimes <- lapply (APTimes, FUN = deleteColsLastRowNA)

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/ALLRAWFILES")
pulses <- read.table(name_logfile, sep="\t", fill=TRUE, col.names=1:(max(count.fields(name_logfile, sep = "\t"))-1))
pulses <- head (pulses, n = 81)
pulses <- tail (pulses, n = 25)
rownames (pulses) <- NULL
colnames(pulses) <- c('num', 'time')

colmins <- lapply (APTimes, FUN = colMinsIndexes)
ini_sites <- lapply (colmins, FUN = meansOfSublists)
ini_mat <- listListsToMatrix(ini_sites)
ini_mat <- nullToNA (ini_mat)
ini_mat <- apply (ini_mat, 2, as.numeric)

if (isanode) {
  print ('Anode > deleting first two pulses')
  donotuse <- c(1, 2) # !! ONLY WHEN ANODE !!
  ini_mat[, donotuse] <- NA
}

soma <- apply (ini_mat, 2, FUN = removeAxonSites)
axon <- apply (ini_mat, 2, FUN = removeSomaSites)

########################

# axon_list <- apply (ini_mat, 2, FUN = indexesAxonAPs)
# axon_mat <- listListsToMatrix(axon_list)
# 
# soma_list <- apply (ini_mat, 2, FUN = indexesSomaAPs)
# soma_mat <- listListsToMatrix(soma_list)
# 
# AxonAPs <- list()
# SomaAPs <- list()
# # They are list of matrices. Each matrix represent one pulse;
# # and will store the times of the APs that were stimulation-induced/spontaneous, respectively.
# # --> not used for the bubble graph but good to have
# for (c in seq(1:length(axon_list))) {
#   tab <- as.matrix (APTimes[[c]] [, axon_list [[c]] ]) # Takes the columns from the corresponding matrix in APTimes
#   AxonAPs [[length(AxonAPs) + 1]] <- tab
# }
# 
# for (c in seq(1:length(soma_list))) {
#   tab <- as.matrix (APTimes[[c]] [, soma_list [[c]] ]) # Takes the columns from the corresponding matrix in APTimes
#   SomaAPs [[length(SomaAPs) + 1]] <- tab
# }

########################

# third <- seq (from = 1, to = 65, by = 3) # Removes every other pulse for clarity of the graph.
# third <- rep(1:65)[!(rep(1:65) %in%  seq (from = 1, to = 65, by = 3))]
# 
# 
# axon [, third] <- NA
# soma [, third] <- NA

odds <- seq (from = 1, to = 65, by = 2) # Removes every other pulse for clarity of the graph.

axon [, odds] <- NA
soma [, odds] <- NA

colnames (axon) <- NULL
colnames (soma) <- NULL

ini_melted_axon <- melt (axon, na.rm = TRUE)
ini_melted_soma <- melt (soma, na.rm = TRUE)

colnames(ini_melted_axon) <- c("APnum", "pulse", "ini_site")
colnames(ini_melted_soma) <- c("APnum", "pulse", "ini_site")

ini_grouped_axon <- group_by (ini_melted_axon, pulse, ini_site)
ini_grouped_soma <- group_by (ini_melted_soma, pulse, ini_site)

counts_axon <- count (ini_grouped_axon)
counts_soma <- count (ini_grouped_soma)

colnames(counts_axon) <- c("pulse", "ini_site", "numAPs")
colnames(counts_soma) <- c("pulse", "ini_site", "numAPs")

#################

x_pulsewidths <- seq (from = 0.1, to = 1.3, by = 0.1)

ggplot(data = counts_axon, mapping = aes (x = pulse, y = ini_site, colour = 'Stimulation-induced')) +
  geom_point(aes (size = numAPs)) +
  
  geom_point (data = counts_soma, mapping = aes (x = pulse, y = ini_site, colour = 'Spontaneous')) +
  geom_point(aes (size = numAPs), shape = '.') +
  # > X and Y axis ticks & limits
  scale_y_continuous (breaks = seq(from = 1, to = num_sections, by = 2),
                      expand = c(0,1), limits = c(1,num_sections), labels = c('0', '2', '4', '6', '8', '10', '12', '14', '16', '18', '20', '22', '24', '26', '28')) +
  
  scale_x_continuous (breaks = seq(from = 5, to = 65, by = 5),
                      expand = c(0,0),
                      limits = c(0, num_pulses + 1), labels = x_pulsewidths) +
  
  scale_size_continuous(range = c(1,6)) +
  
  # > X and Y axis titles & graphics
  xlab ('') +
  theme (axis.title.x = element_text (family = 'Calibri Light', face = 'plain')) +
  theme(axis.title.x=element_text(margin=margin(18,0,0,0))) +
  theme(axis.text.x = element_text(family = 'Calibri Light', colour = 'black')) +
  
  ylab ('') +
  theme (axis.title.y = element_text (family = 'Calibri Light', face = 'plain')) +
  theme(axis.title.y=element_text(margin=margin(0,18,0,0))) +
  theme(axis.text.y = element_text(family = 'Calibri Light', colour = 'black')) +
  
  theme(axis.ticks.length=unit (0.2, 'cm')) +
  theme(axis.line = element_line(colour = 'transparent')) +
  
  # > shape of the whole plot  
  #  coord_fixed (ratio = 1.2) +
  # increase ratio makes graph taller
  
  # > title  
  # ggtitle (name) +
  # theme(plot.title=element_text(family = "Calibri Light", size=20)) +
  # theme(plot.title=element_text(hjust = 0.5)) +
  # theme(plot.title=element_text(margin=margin(0,0,10,0))) +
  
  # > subtitle  
  # labs (subtitle = 'Initiation sites bubble graph') +
  # theme(plot.subtitle=element_text(hjust=0.5, family = 'Calibri Light', margin=margin(0,0,12,0))) +

# > bubble legend  
labs (size = '# APs') +
  theme(legend.text=element_text(family = 'Calibri Light')) +
  theme(legend.title=element_text(family = 'Calibri Light')) +
  theme(legend.key=element_rect(NA)) +
  theme (legend.position = 'top') +
  guides(size = guide_legend(override.aes = list(colour='#2a2a2a'))) +
  
  # > colour legend
  labs (colour = '') +
  scale_colour_manual(name = '', 
                      values = c('Stimulation-induced' = '#025D8C', 'Spontaneous' = '#FF4040')) +
  guides(colour = guide_legend(override.aes = list(size=4))) +
  
  theme(
    # panel.background = element_rect(fill = "transparent") # bg of the panel
    plot.background = element_rect(fill = "transparent") # bg of the plot
    # panel.grid.major = element_blank() # get rid of major grid
    , panel.grid.minor = element_blank() # get rid of minor grid
    , legend.background = element_rect(fill = "transparent") # get rid of legend bg
  )
