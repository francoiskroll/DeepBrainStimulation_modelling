# PREPULSE CATHODE AP DELAY

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/ALLRAWFILES")
library(extrafont)
#  loadfonts(device = "win")
library(RColorBrewer)

# What are the pulse widths you tested (in ms)?
first = 0.02
last = 1.3
increment = 0.02

# There are 33 columns to the .dat file
dat_colnames = c('Pulse #', 'Cell #', 'X', 'Y', 'Z', 'Thresh voltage(V)', 'ubound', 'lbound', 'Required APs', 
                 'Nbr extra APs during stim', 'Avg spikes/sec B(Hz)', 'Avg Inst firing B (Hz)',
                 'Inst rate STD B (Hz)', 'Avg spikes/sec SOMA B(Hz)',
                 'Avg Inst firing SOMA B (Hz)', 'Avg spikes/sec D (Hz)',
                 'Avg Inst firing D', 'Inst rate STD D (Hz)', 'Avg spikes/sec SOMA D(Hz)',
                 'Avg Inst firing SOMA D (Hz)', 'Avg spikes/sec A (Hz)', 'Avg Inst firing A',
                 'Inst rate STD A (Hz)', 'Avg spikes/sec SOMA A(Hz)', 'Avg Inst firing SOMA A (Hz)',
                 'Avg freq D aft 100ms(Hz)', 'Delay after stim (ms)', 'AP site#1', 'AP site#2',
                 'AP time1', 'AP time2', 'soma_orig', 'soma_orig2', 'Nbr soma AP during stim')

# Import the .dat tables

prepulse_cathode_4ms <- read.table ('prepulse_cathode.dat', header = FALSE, sep = '', col.names = dat_colnames,  skip = 12)
prepulse_cathode_5ms <- read.table ('prepulse_cathode_5ms.dat', header = FALSE, sep = '', col.names = dat_colnames,  skip = 12)
prepulse_cathode_6ms <- read.table ('prepulse_cathode_6ms.dat', header = FALSE, sep = '', col.names = dat_colnames)
prepulse_cathode_735ms <- read.table ('prepulse_cathode_735ms.dat', header = FALSE, sep = '', col.names = dat_colnames, skip = 12)

# Extract the thresholds from the .dat tables
precath4_thr <- prepulse_cathode_4ms [, 6]
precath5_thr <- prepulse_cathode_5ms [, 6]
precath6_thr <- prepulse_cathode_6ms [, 6]
precath735_thr <- prepulse_cathode_735ms [, 6]

# Fill in precath6_thr with NAs.
precath6_thr <- append(precath6_thr, rep(NA, 22), after = 0)

thresholds <- as.data.frame (cbind (precath4_thr, precath5_thr, precath6_thr, precath735_thr))

colnames (thresholds) <- c('4ms', '5ms', '6ms', '7.35ms')

thresholds <- thresholds [-1,]
thresholds <- emptyThresh10(thresholds)

pulse_widths <- seq(from = first, to = last, by = increment)

pairedcol <- c('#343335', '#B1AEB2',
               '#043264', '#4476E4',
               '#506620', '#98C23C',
               '#871F07', '#F33F15',
               '#7B109C', '#CC5BEF')

matplot (pulse_widths, thresholds,
         col = pairedcol, family = 'Calibri Light', bg = NA, bty = 'l', asp = 0,
         lty = 1, lwd = 2, type = 'l',
         xlab = '', xlim = c(0.0, 1.4), xaxs = 'i', xaxt = 'n',
         ylab = '', ylim = c(0, 8), yaxs = 'i', yaxt = 'n')
par (bg = NA)

matpoints (pulse_widths, thresholds, bg = NA,
           col = pairedcol, type = 'p', pch = 21, cex = 0.80)

axis (side = 1, 
      at = c(0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4), 
      labels = c('0.0', '', '0.4', '0.6', '0.8', '1.0', '1.2', '1.4'),
      family = 'Calibri Light')

axis (side = 2, at = c(0, 2, 4, 6, 8), labels = c('0', '2', '4', '6', '8'), family = 'Calibri Light')

