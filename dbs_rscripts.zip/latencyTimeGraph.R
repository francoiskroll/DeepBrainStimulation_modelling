# LATENCY TIMES GRAPH

# For one waveform / range of pulse widths.
# library(extrafont)
# loadfonts(device = "win")

waveform = "biphasic_anode"
waveform_num = 10
logfile = paste (waveform, '.log', sep = '')

AllDeltaInitimeVsPulse <- function (col, pulse_times) {
  temp <- expand.grid (col, pulse_times)
  colnames(temp) <- c('ini', 'pulse')
  delta <- temp$ini - temp$pulse 
  return (delta)
}

sortDeltas <- function (col) {
  temp <- which (col <= 0)
  col [temp] <- NA
  
  temp <- which (col >= 7.36)
  col [temp] <- NA
  
  return (col)
}

# Get pulse times

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/simulations_NewPulseShapeFiles/ALLRAWFILES")

pulses <- read.table(logfile, sep="\t", fill=TRUE, col.names=1:(max(count.fields(logfile, sep = "\t"))-1))
pulses <- head (pulses, n = 81)
pulses <- tail (pulses, n = 25)
rownames (pulses) <- NULL
colnames(pulses) <- c('num', 'time')

pulse_times <- as.numeric(as.vector(pulses$time))

# Get AP initiation times
  # ! APs in .log are the APs output by the neuron, not the initiation times.
  # You need to get them from APTimes list of matrices (minimum of each column).
  # They are computed for bubbles graph.

# Compute again APTimes.
  # ! Load functions on the side (functionsForBubbles.R)

timefile = paste (waveform, '.time', sep = '')
num_sections <- 29

num_col <- max(count.fields(timefile, sep = "\t"))
times <- read.table(timefile, sep="\t", fill=TRUE, col.names=1:(num_col-1))
num_pulses <- nrow (times) / num_sections
Raw <- split (times, rep (0:(nrow(times)/29), each = 29, length.out = nrow(times)))
APTimes <- Raw
APTimes <- APTimes [- 1]
APTimes <- lapply (APTimes, FUN = extendMatrix)
APTimes <- lapply (APTimes, FUN = lastLineFirst)
APTimes <- lapply (APTimes, FUN = deleteFirstCol) 
APTimes <- lapply (APTimes, FUN = correctTimeFile)
APTimes <- lapply (APTimes, FUN = deleteColsLastRowNA)

# !!! When it is anode, you need to delete first two matrices (impossible to stimulate)
if ((waveform_num %% 2) == 0) {
  APTimes [[1]] <- NULL
  APTimes [[1]] <- NULL
}

min_inds <- lapply (APTimes, FUN = colMinsIndexes)
ini_sites <- lapply (min_inds, FUN = meansOfSublists)
ini_sites <- listListsToMatrix(ini_sites)
ini_sites <- nullToNA (ini_sites)
ini_sites <- apply (ini_sites, 2, as.numeric)

# Get the indexes of the APs which are initiated in the axon (different than 1 or 1.5)
indexesAxonAPs <- function (col) {
  axon_inds <- which (col != 1 & col != 1.5)
  return (axon_inds)
}

axon_list <- apply (ini_sites, 2, FUN = indexesAxonAPs)
axon_mat <- listListsToMatrix(axon_list)

# Use these indexes to take only the times I need from APTimes

AxonAPs <- list()
SomaAPs <- list()
# They are list of matrices. Each matrix represent one pulse;
# and will store the times of the APs that were stimulation-induced/spontaneous, respectively.

for (c in seq(1:length(axon_list))) {
  tab <- as.matrix (APTimes[[c]] [, axon_list [[c]] ]) # Takes the columns from the corresponding matrix in APTimes
  AxonAPs [[length(AxonAPs) + 1]] <- tab
}

# Get the minimum of each column.
initiations <- lapply(AxonAPs, function (x) {apply (x, 2, min, na.rm = TRUE)})

# FOR ALL NOW

initimes <- listListsToMatrix(initiations)

deltas <- lapply (initiations, FUN = AllDeltaInitimeVsPulse, pulse_times)
deltas <- listListsToMatrix(deltas) # temp is a big matrix of 65 cols and num of axon APs (max 27) x num of pulses (25) = 675 lines max.

# Sort deltas
# Replace by NAs deltas that are negative or over 7.36 (over the interpulse delay)
deltas <- apply (deltas, 2, FUN = sortDeltas)

mat <- deltas

inds_notNA <- apply (mat, 2, function (x) {which (! is.na (x))})
inds_notNA <- lapply (inds_notNA, as.vector)

Latencies <- list()

for (i in seq(1:length(inds_notNA))) {
  inds <- inds_notNA [[i]]
  notNAs <- as.vector (deltas [inds, i])
  Latencies [[length(Latencies) + 1]] <- notNAs
}

latency_mat <- listListsToMatrix(Latencies)

 if ((waveform_num %% 2) == 0) {
   odds <- seq (from = 1, to = 63, by = 2)
 } else {
   odds <- seq (from = 1, to = 65, by = 2)
 }

latency_mat [, odds] <- NA

latency_trans <- t(latency_mat)

pairedcol <- c('#343335', '#B1AEB2',
               '#043264', '#4476E4',
               '#506620', '#98C23C',
               '#871F07', '#F33F15',
               '#7B109C', '#CC5BEF')

if ((waveform_num %% 2) == 0) { # if ANODE
  pulse_widths = seq(0.06, 1.3, 0.02)
}

if ((waveform_num %% 2) != 0) { # if CATHODE
  pulse_widths = seq(0.02, 1.3, 0.02)
}

par (bg = NA)
matplot (pulse_widths, latency_trans, 
         col = pairedcol[waveform_num], family = 'Calibri Light',
         type = 'p', pch = 20,
         xlab = '', ylab = '',
         xlim = c(0.0, 1.33), ylim = c(0.0, 8.0),
         xaxs = 'i', yaxs = 'i',
         xaxt = 'n', yaxt = 'n', bg = NA)
abline (a = 0, b = 1, col = 'yellow', lwd = 2)
axis (1, at = c(seq(0.0, 1.3, 0.1)), 
      labels = c('0', '', '', '', '0.4', '', '', '', '0.8', '', '', '', '1.2', ''), family = 'Calibri Light')
axis (2, at = c(seq(0.0, 8.0, 1.0)), labels = c('0', '1', '2', '3', '4', '5', '6', '7', '8'), family = 'Calibri Light')
