##########################################################################################################

# BUBBLE GRAPH INITIATION SITES VS. PULSE SHAPE

# This is a test. You'll need to change some stuff once you have actual data.
# I am testing with two times the same data.
# I think we should start from the ini_counts matrices.

# For eg. you have one ini_map matrix for pulse shape 1 = ini_map1.
# and one ini_map matrix for pulse shape 2 = ini_map2.

ini_map1 <- ini_map
ini_map2 <- ini_map

# First we need to append all the columns of each ini_map into one column.

ini_map1 <- matrix (ini_map1, ncol = 1)
ini_map2 <- matrix (ini_map2, ncol = 1)

# Then cbind these matrices (columns) together into one matrix.
ini_shape <- cbind (ini_map1, ini_map2)
# each column = one pulse shape

melted_shape <- melt (ini_shape, na.rm = TRUE)
rownames(melted_shape) <- NULL # that's just cleaner
melted_shape <- melted_shape [,-1]
colnames (melted_shape) <- c('shape', 'ini_site')

grouped_shape <- group_by (melted_shape, shape, ini_site)
shape_counts <- count (grouped_shape)
colnames (shape_counts) <- c('shape', 'ini_site', 'numAPs')

# Bubble graph
x_shapes <- as.vector(unlist (unique (shape_counts$shape)))
y_sections <- as.vector (seq(from = 1, to = num_sections, by = 1))

bubble_shape <- ggplot(data = shape_counts, mapping = aes (x = shape, y = ini_site)) +
  geom_point(aes (size = numAPs)) # adds points whose areas are proportional to numAPs

bubble_shape <- bubble_shape + xlim (range(1:length(x_shapes)))
bubble_shape <- bubble_shape + ylim (range(1:num_sections))
bubble_shape <- bubble_shape + xlab ('Pulse shape #')
bubble_shape <- bubble_shape + ylab ('Initiation section')
bubble_shape <- bubble_shape + ylab ('Initiation section')
bubble_shape <- bubble_shape + scale_y_continuous (breaks = seq(from = 1, to = num_sections, by = 2), limits = range(1:num_sections))
bubble_shape <- bubble_shape + scale_x_continuous (breaks = seq(from = 1, to = length (x_pulses), by = 1), expand = c(0, 0.3))
bubble_shape <- bubble_shape + coord_fixed (ratio = 0.09)

# Same code than above. You might need to correct a couple of stuff.