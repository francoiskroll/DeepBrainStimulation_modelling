# FUNCTIONS FOR DBS PROJECT SCRIPTS

# Takes a big appended file of pulses waveforms as input
# and return the corresponding matrix where each column is one pulse.
fromWaveformsToMatrix <- function (waveform) {
  waveform <- waveform [,-1] # deletes the first column (times)
  splitted <- split (waveform, ceiling(seq_along(waveform)/736))
  waveform_mat <- listListsToMatrix(splitted)
  return (waveform_mat)
}

# Replace in a tab the thresholds which are = 10 by NA
emptyThresh10 <- function (col) {
  if (length(which (col == 10)) != 0) {
    ind <- which (col == 10)
    col [ind] <- NA
    return (col)
  } else {
    break
  }
}

indexesAxonAPs <- function (col) {
  axon_inds <- which (col != 1.0 & col != 1.5)
  return (axon_inds)
}

indexesSomaAPs <- function (col) {
  soma_inds <- which (col == 1 | col == 1.5)
  return (soma_inds)
}


removeAxonSites <- function (col) {
  col [which (col != 1.0 & col != 1.5)] <- NA
  return (col)
}

removeSomaSites <- function (col) {
  col [which (col == 1.0 | col == 1.5)] <- NA
  return (col)
}

lastLineFirst <- function (tab) {
  tmp <- tab [nrow(tab),] # Last line as tmp variable
  tab <- rbind (tmp, tab) # Inserts last line at the beginning of the table
  row.names (tab) <- NULL # Resets line names
  tab <- tab [-(nrow(tab)),] # Deletes the last line
  return(tab)
}

correctTimeFile <- function (tab) {
  
  for (c in 1:ncol(tab)) { # c loops through the columns of pulse.
    lbound = min(tab[,c], na.rm = TRUE) # For each column, compute the lower bound (excluding NA).
    # The minimum should belong to the correct AP as columns that might be shifted are always shifted to the right, not to the left.
    ubound = lbound + 2 # Correct data should not be bigger than minimum + 2 ms.
    correctcol = tab[,c] >= lbound & tab[,c] < ubound # Check if each row is correct (TRUE) or not (FALSE).
    false_index = which (correctcol == FALSE) # Returns the index of the rows that are not correct.
    
    if (length(false_index) != 0) { # If some rows need to be corrected.
      for (r in false_index) { # r loops through the rows that are not correct.
        tab[r,c:ncol(tab)] <- c(NA, tab [r,c:(ncol(tab)-1)]) # Replace 
        # Insert NA where value is not in the correct column and shift the whole row to the right.
      }
    }
  }
  return(tab)
}

colMinsIndexes <- function (tab) {
  min_ind <<- apply (tab, 2, function(x) which (x == min(x, na.rm = TRUE)))
}

deleteColsLastRowNA <- function (tab) {
  tab <- tab [,(!(is.na(tab [nrow(tab), ])))]
  return (tab)
}

meansOfSublists <- function (list_lists) {
  mean_list <- lapply (list_lists, FUN = mean)
  return (mean_list)
}

nullToNA <- function(mat) {
  mat[sapply(mat, is.null)] <- NA
  return (mat)
}

listListsToMatrix <- function (list_lists) {
  max_length <- max(unlist(lapply (list_lists, FUN = length)))
  matrix_lists <- sapply (list_lists, function (x) {length (x) <- max_length; return (x)})
  rownames(matrix_lists) <- seq (1:nrow(matrix_lists))
  return (matrix_lists)
}

deleteFirstCol <- function (mat) {
  mat <- mat [,-1]
  colnames(mat) <- NULL
  return (mat)
}

extendMatrix <- function (tab) {
  add <- matrix (data = NA, nrow = nrow(tab), ncol = 50)
  tab <- as.matrix (cbind (tab, add))
  colnames (tab) <- NULL
  return (tab)
}

getStimulationAPsIndexes <- function (pulse_times, tab) {
  
  stim_ind <- c() # Vector that will store the indexes of the stimulation-induced APs.
  ini_times <- apply (tab, 2, FUN = min, na.rm = TRUE) 
  # We are looking at the time when the AP is initiated, ie. the minimum of the column.
  
  for (ini in ini_times) {
    for (pul in pulse_times) {
      if (ini > pul & ini <= pul + 4) { # Condition is the same than in the model.
        # ie. to be stimulation-induced, AP has to happen within 4 ms after the pulse.
        stim_ind <- append (stim_ind, which (ini_times == ini))
      }
    }
  }
  return (stim_ind)
}