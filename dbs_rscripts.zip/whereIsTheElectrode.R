# WHERE IS THE ELECTRODE?

########################

# FUNCTIONS

splitByCell <- function (tab, lines) {
  splitted <- split (tab, rep (0:nrow(tab)/lines, each = lines, length.out = nrow(tab)))
  for (i in 1:(nrow(tab)/lines)) {
    assign (paste("cell",i,sep=""), splitted[[i]], envir = .GlobalEnv)
  }
}

# From the voltage file, generates a matrix where 
# each column is a cell, each row a compartment and each value the voltage.
voltsMatrixFromAppendedFile <- function (voltage, num_cells, num_compartments) {
  volts <- matrix (data = NA, nrow = num_compartments, ncol = num_cells)
  splitted <- split (voltage, rep (0:nrow(voltage)/num_compartments, each = num_compartments, length.out = nrow(voltage)))
  for (i in 1:num_cells) {
    volts [,i] <<- splitted [[i]]$V2
  }
}

########################

setwd("C:/Users/Fran�ois/Dropbox/DBS Modelling Project/Miocinovic 2006/miocinovic2006_pulseLoop/fem_voltage")
voltage_file <- read.table ('STNtype1_bipo1_encap250_elecH2Snew2.txt', sep = '=')
voltage <- read.table ('STNtype1_bipo1_encap250_elecH2Snew2.txt', sep = '=', skip = 70)

########################

# WHERE ARE THE LOWEST VOLTAGES?

# Which cell is at the lowest voltage?
which (voltage$V2 == min (voltage$V2)) # Returns index of the line where the minimum voltage is.
# Voltage minimum of the whole file is line 10202.

# Which compartment of cell 0 is at the lowest voltage?
splitByCell (voltage, 509)
which (cell1$V2 == min (cell1$V2)) # Returns index of the line where the minimum voltage.
# Voltage 506 is the minimum of cell 0.

########################

# 3D CELL LOCATIONS

# Prepare the data
cell_coordinates <- head(read.table ('STNtype1_bipo1_encap250_elecH2Snew2.txt', sep = '='), 70)
cell_coordinates <- cell_coordinates [-1,] # First line is the number of cells.
row.names (cell_coordinates) <- NULL # Reset line numbers.

# Separate by X, Y, Z coordinate
tmp_x <- vector (length = nrow(cell_coordinates)/3) # Initialize the vectors.
tmp_y <- vector (length = nrow(cell_coordinates)/3)
tmp_z <- vector (length = nrow(cell_coordinates)/3)

for (i in 1:(nrow(cell_coordinates)/3)) {
  tmp_x [i] <- cell_coordinates [3*i-2, 2] # X coordinates = lines 1, 4, 7, ...
  tmp_y [i] <- cell_coordinates [3*i-1, 2] # Y coordinates = lines 2, 5, 8, ...
  tmp_z [i] <- cell_coordinates [3*i, 2] # Z coordinates = lines 3, 6, 9, ...
}

# Prepare a coordinates table
library (plot3D)

coordinates <- data.frame(tmp_x, tmp_y, tmp_z)
colnames(coordinates) = c('X', 'Y', 'Z')

# Plot
x <- coordinates$X
y <- coordinates$Y
z <- coordinates$Z

scatter3D(x, y, z, colvar = NULL, col = 'blue', pch = 20, cex = 0.5, theta = 25, phi = 8)
text3D(x, y, z,  labels = rownames(coordinates), add = TRUE, colkey = FALSE, cex = 0.5)
# default seems to be theta = 40. + turns it counter-clockwise; - turns it clockwise
# default seems to be phi = 40. + you see it more from above; - you see it more from below

# Minimum voltage of the whole file is line 10202. This voltage should belong to cell #20.
# --> Cell #20's lines should be from line 10180 to line 10689.

########################

# 3D CELL LOCATIONS + VOLTAGE SCALE

# --> Are all compartments of cell 20 at low voltage? That would be another evidence that electrode is near.

# Generate the voltage matrix where each cell = one column, each compartment = one row, each value = voltage.
num_cells = 23
volts <- matrix (data = NA, nrow = 509, ncol = 23)
colnames(volts) <- paste ('cell', seq(1:num_cells), sep = '')

voltsMatrixFromAppendedFile (voltage, num_cells = 23, num_compartments = 509)

# Compute the mean voltage of each cell, ie. of each column in the voltage file.
cell_means <- colMeans (volts)
min (cell_means)
which (cell_means == min (cell_means))
# Smallest average voltage is at cell 21

max (cell_means)
which (cell_means == max (cell_means))
# Highest average voltage is at cell 11

# Add colours to the points depending on their average voltage = voltage scale.
  # (default is to use z axis as scale for the colours)

scatter3D(x, y, z, colvar = cell_means, pch = 20, cex = 1.5, theta = 25, phi = 8)
text3D(x, y, z,  labels = rownames(coordinates), add = TRUE, colkey = FALSE, cex = 0.7)

# Other question that could be asked is:
  # Are the voltages in each cell very different or close to each other?
  # Or in other words, the distribution (especially the range) of the compartments' voltages in each individual cell.
  # if they are rather close and do not overlap much that would mean something 
  # (ie. electrode is really close to cell 21)
